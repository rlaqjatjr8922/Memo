@echo off
chcp 65001 >nul

:: 관리자 권한 확인
net session >nul 2>&1

if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo Net-Class 방화벽 규칙 확인 중...

powershell -NoProfile -Command ^
"$r = Get-NetFirewallRule -DisplayName 'Block Net-Class School Server' -ErrorAction SilentlyContinue; ^
if ($r) { ^
    Write-Host '[SKIP] 이미 방화벽 규칙이 존재합니다.' ^
} else { ^
    New-NetFirewallRule -DisplayName 'Block Net-Class School Server' -Direction Outbound -RemoteAddress '10.46.64.249' -Action Block | Out-Null; ^
    Write-Host '[OK] 방화벽 규칙을 새로 생성했습니다.' ^
}"

echo.
pause