@echo off
chcp 65001 >nul

:: 관리자 권한 확인
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo [1/3] 방화벽 차단 해제...

powershell -NoProfile -Command ^
"Disable-NetFirewallRule -DisplayName 'Block Net-Class School Server' -ErrorAction SilentlyContinue"

echo [2/3] Net-Class 서비스 시작...

powershell -NoProfile -Command ^
"Start-Service NetClassHostSvc -ErrorAction SilentlyContinue; ^
Start-Service remoteHostSvc -ErrorAction SilentlyContinue"

echo [3/3] 연결 확인을 위해 잠시 대기...
timeout /t 5 /nobreak >nul

powershell -NoProfile -Command ^
"$c=Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object {$_.RemoteAddress -eq '10.46.64.249' -or $_.RemotePort -in 7787,7788}; ^
if($c){Write-Host '[OK] Net-Class 서버 연결이 복구되었습니다.'; $c | Format-Table LocalAddress,LocalPort,RemoteAddress,RemotePort,State -AutoSize} ^
else{Write-Host '[INFO] 차단은 해제됐지만 아직 서버 연결이 확인되지 않습니다.'}"

echo.
pause