@echo off
chcp 65001 >nul

:: 관리자 권한 확인
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo [1/4] 방화벽 차단 활성화...

powershell -NoProfile -Command ^
"$r=Get-NetFirewallRule -DisplayName 'Block Net-Class School Server' -ErrorAction SilentlyContinue; ^
if($r){Enable-NetFirewallRule -DisplayName 'Block Net-Class School Server'} ^
else{New-NetFirewallRule -DisplayName 'Block Net-Class School Server' -Direction Outbound -RemoteAddress '10.46.64.249' -Action Block | Out-Null}"

echo [2/4] Net-Class 프로세스 종료...

powershell -NoProfile -Command ^
"Get-Process Host,rncHost -ErrorAction SilentlyContinue | Stop-Process -Force"

echo [3/4] Net-Class 서비스 중지...

powershell -NoProfile -Command ^
"Stop-Service NetClassHostSvc -Force -ErrorAction SilentlyContinue; ^
Stop-Service remoteHostSvc -Force -ErrorAction SilentlyContinue"

echo [4/4] 연결 상태 확인...

powershell -NoProfile -Command ^
"$c=Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object {$_.RemoteAddress -eq '10.46.64.249' -or $_.RemotePort -in 7787,7788}; ^
if($c){Write-Host '[WARNING] 아직 연결이 남아 있습니다.'; $c | Format-Table LocalAddress,LocalPort,RemoteAddress,RemotePort,State -AutoSize} ^
else{Write-Host '[OK] Net-Class 연결이 차단되었습니다.'}"

echo.
pause